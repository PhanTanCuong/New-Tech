const posts = [
    {
        id: "1",
        title: "Week3",
        body: "Xây dựng web server đơn giản",
        image: "image/image.png",
        createdAt: "16/10/2023",
        author: "Phan TanCuong",
        comments: [
            {
                id: "1",
                body: "Good job",
                author: "Phan Tan Kien",
                createdAt: "16/10/2023"
            },
            {
                id: "2",
                body: "Nai su",
                author: "Cuong Phan Tan",
                createdAt: "16/10/2023"
            }
        ]
    },
    {
        id: "2",
        title: "Week4",
        body: "Xây dựng webserver sử dụng ExpressJS",
        image: "image/image.png",
        createdAt: "16/10/2023",
        author: "Phan TanCuong",
        comments: [
            {
                id: "1",
                body: "Good job",
                author: "Phan Tan Kien",
                createdAt: "16/10/2023"
            },
            {
                id: "2",
                body: "Nai su",
                author: "Cuong Phan Tan",
                createdAt: "16/10/2023"
            }
        ]
    },
    {
        id: "3",
        title: "Week5",
        body: "Xây dựng blog đơn giản sử dụng ExpressJS với HBS template",
        image: "image/image.png",
        createdAt: "16/10/2023",
        author: "Phan TanCuong",
        comments: [
            {
                id: "1",
                body: "Good job",
                author: "Phan Tan Kien",
                createdAt: "16/10/2023"
            },
            {
                id: "2",
                body: "Nai su",
                author: "Cuong Phan Tan",
                createdAt: "16/10/2023"
            }
        ]
    },
    
];

module.exports = {
    posts
};