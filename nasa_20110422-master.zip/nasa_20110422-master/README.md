# NASA_20110422
NASA website using REACTJS &amp; NODEJS 

# Student: Nguyen Minh Tri
# ID: 20110422
# Created Date: 28/10/2023
# Link video: https://www.youtube.com/watch?v=LCC0qZrV0hU 
## Command to run: 1 - npm install --> 2 - npm run watch
